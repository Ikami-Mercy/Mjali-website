# bmgf
Youth Advocacy Accelarator (Survey System)

# requrements
 
 # > sql server 2008
 # > Apache Server
 # > php 5.6
